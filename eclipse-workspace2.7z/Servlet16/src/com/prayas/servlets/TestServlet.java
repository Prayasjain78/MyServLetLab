package com.prayas.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	PrintWriter out=response.getWriter();
	Cookie cks[]=request.getCookies();
	out.println("<h1>"+cks);
	boolean jsidflag=false;
	boolean jlcflag=false;
	if(cks==null||cks.length==0) {
		out.println("<h1>OOOO no Cookies</h1>");
	}else {
		for(Cookie ck:cks) {
			String cn=ck.getName();
			String cv=ck.getValue();
			out.println("<h1>"+cn+"-------"+cv+"</h1>");
			if(cn.equals("JSESSIONID")) {
				jsidflag=true;
			}
			if(cn.equals("JLC")) {
				jlcflag=true;
				ck.setMaxAge(0);
				response.addCookie(ck);
			}
			if(jsidflag)
				out.println("<h1>JSESSIONID Cookie is Found...");
			else
				out.println("<h1>JSESSION Cookie is Not Found...");
			if(jlcflag)
				out.println("<h1>JLC Cookie is Found....");
			else
				out.println("<h1>JLC Cookie is not Found....");
			Cookie c1=new Cookie("JLC","Welcometo JLC");
			response.addCookie(c1);
			Cookie c2=new Cookie("EM","jain.prayas78.com");
			response.addCookie(c2);
			Cookie c3=new Cookie("PH","9999999");
			response.addCookie(c3);
			

		       
		}
	}
	
	}

}
