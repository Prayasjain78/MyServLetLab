package com.prayas.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



public class RemoveFromCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		HttpSession sess=req.getSession(false);
		if(sess==null) {
			req.setAttribute("MSG","Session is destroyed");
		}else {
			String bnm=req.getParameter("bname");
			//reoving the client books from session 
			sess.removeAttribute(bnm);
		}
		RequestDispatcher rd=req.getRequestDispatcher("showcart.prayas");
		rd.forward(req, res);
	}
	
	

}
