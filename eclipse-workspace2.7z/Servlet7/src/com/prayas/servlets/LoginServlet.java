package com.prayas.servlets;

import java.io.IOException;
import java.io.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    
	
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
				
		System.out.println("service of TestServlet");
		String unm=req.getParameter("username");
		String pwd=req.getParameter("password");
		Writer out=res.getWriter();
		out.write("<h1>Hi, Welcome to Prayas");
		String page="";
		if(unm.equals(pwd)) {
			page="/WEB-INF/home.html";
			RequestDispatcher rd=req.getRequestDispatcher(page);
			rd.forward(req, res);
		}else {
			
			page="/WEB-INF/error.html";
			RequestDispatcher rd=req.getRequestDispatcher(page);
			rd.forward(req, res);
		}
		out.write("<h1>Again,Welocome to Prayas");
		System.out.println("****service completed-Last Statement****");
	}

}
