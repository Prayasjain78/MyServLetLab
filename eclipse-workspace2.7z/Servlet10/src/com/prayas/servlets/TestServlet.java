package com.prayas.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		//1.Request parameters
		String un=req.getParameter("uname");
		
		String pwd=req.getParameter("password");
		//2.display request parameters
		
		PrintWriter out=res.getWriter();
		out.println("<h1>Username :"+un);
		out.println("<br/>Password :"+pwd);
		out.println("<hr/>");
		out.println("Request Headers");
		//3.Request Headers
		Enumeration e=req.getHeaderNames();
		while(e.hasMoreElements()) {
			
			String hn=e.nextElement().toString();
			String hv=req.getHeader(hn);
			out.println("<br/> "+hn+ " : "+hv);
		}
		out.println("<hr/>");
		out.println("Locale Info");
		
		//Locale supported by Browser.
		out.println("<br/>req.getLocale(): "+req.getLocale());
		out.println("<hr/>");
		out.print("Other Info");
		//Other information from Request
		out.println("<br/>METHOD "+req.getMethod());
		out.println("<br/>Request URI: "+req.getRequestURI());
		out.println("<br/>Request URL: "+req.getRequestURL());
		out.println("<br/>Protocol : "+req.getProtocol());
		out.println("<br/>Content Length :"+req.getContentLength());
		out.println("<br/>Content Type: "+req.getContentType());
		out.println("<br/>Remote Address :"+req.getRemoteAddr());
		out.println("<br/>Remote Port : "+req.getRemotePort());
		out.println("<br/>Remote Host :"+req.getRemoteHost());
		out.println("<br/>Server Port : "+req.getServerPort());
		out.println("<br/>Server Name :"+req.getServerName());
		out.println("<br/>QueryString():"+req.getQueryString());
		out.println("<br/>req.getServletPath(): "+req.getServletPath());
		out.println("<br/>req.getContextPath() : "+req.getContextPath());
		
	}

}
