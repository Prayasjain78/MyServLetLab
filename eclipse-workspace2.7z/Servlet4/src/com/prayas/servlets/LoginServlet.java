package com.prayas.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name="regServlet",urlPatterns= {"/register.prayas"})
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException {
		
		String fn=req.getParameter("fname");
		String em=req.getParameter("email");
		String ph=req.getParameter("phone");
		String ge=req.getParameter("gender");
		String ti=req.getParameter("timings");
		String co=req.getParameter("course");
		String cous[]=req.getParameterValues("course");
		String re=req.getParameter("remarks");
		//process the data
		String msg="your Enquiry Has been Added Successfully";
		System.out.println("Full name :"+fn);
		System.out.println("Email id : "+em);
		System.out.println("Phone no. : "+ph);
		System.out.println("Gender : "+ge);
		System.out.println("Timings : "+ti);
		System.out.println("Course :"+co);
		System.out.println("All Courses :");
		if(cous!=null)
			for(String c:cous) {
				System.out.println(c);
			}
		System.out.println("Remarks : "+re);
		
		//send response
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		out.println("<h1>Welcome to Java Page");
		out.println("<h1>"+msg+"</h1>");
		out.println("<h1>Full name :"+fn);
		out.println("<h1>Email Id :"+em);
		out.println("<h1>Phone no :"+ph);
		out.println("<h1>Gender : "+ge);
		out.println("<h1>Timings : "+ti);
		out.println("<h1>Course : "+co);
		out.println("<h1>All course :");
		if(cous!=null){
			for(String c:cous) {
				out.println("<br/>"+c);
			}
			out.println("<h1>Remarks :"+re);
		}
				
				
				
		
				
	}
}
