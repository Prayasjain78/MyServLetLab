package com.prayas.servlets;

import java.io.*;
import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



public class SearchBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	String cat=req.getParameter("category");
	if(cat!=null&& cat.equals("Java")) {
		ArrayList<String> blist=new ArrayList<String>();
		blist.add("Java");
		blist.add("Python");
		blist.add("Jsp");
		blist.add("Servlet");
		blist.add("Angular");
		blist.add("Hibernate");
		blist.add("Spring");
		blist.add("Testing");
		blist.add(".Net");
		HttpSession sess=req.getSession();
		sess.setAttribute("BOOKS", blist);
	}else {
		
		req.setAttribute("MSG", "No books found with category"+cat);
	}
	RequestDispatcher rd=req.getRequestDispatcher("showbooks.jsp");
	rd.forward(req, res);
	}

}
