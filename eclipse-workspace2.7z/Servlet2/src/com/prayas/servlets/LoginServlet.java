package com.prayas.servlets;

import java.io.IOException;
import java.io.Writer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name="/MyLogin",urlPatterns= {"/login.prayas"})
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
     //Collectin Client Data
	String unm=req.getParameter("username");
	String pwd=req.getParameter("password");
	String msg="";
	//Veryfying Cliet DATA
	if(unm.equals(pwd)) {
		msg="<h1>Login Successfuly,<br>Welcome to HomePage<br/>";
	}else
	{
		msg="<h1>Login Failed, Invalid Username and Password";
	}
	//Preparing the Response
	 Writer out=res.getWriter();
		out.write(msg);
	
	
	}

}
