package com.prayas.servlets;

import java.io.IOException;
import java.io.Writer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    protected void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
    	//Collecting Client data
    	String unm=req.getParameter("username");
    	String pwd=req.getParameter("password");
    	String msg="";
    	
    	//VeryFying Client data
    	if(unm.equals(pwd)) {
    		msg="<h1>Login Successsfully<br/>Welcome to Our HomePage";
    	}else {
    		msg="<h1>Logon Failed<br/>Invalid Username or Password";
    	}
    	//Prepare the response
    	Writer out=res.getWriter();
    	out.write(msg);
    	
    }

}
